package poseidon.external;

import java.time.LocalDate;
import java.time.LocalTime;

public class Stampante {
	
	public static int stampa(LocalDate data, LocalTime ora, String targa) {
		// FUNZIONE NON IMPLEMENTATA
		return 0;
	}

}
