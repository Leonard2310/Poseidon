package poseidon.external;

public class SistemaDiPagamento {

	// SISTEMA ESTERNO NON IMPLEMENTATO

	public static boolean elaborazioneAcquisto(String tipologiaPagamento) {
		return true;
	}

}
